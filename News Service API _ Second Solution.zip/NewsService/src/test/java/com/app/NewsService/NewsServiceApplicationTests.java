package com.app.NewsService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
